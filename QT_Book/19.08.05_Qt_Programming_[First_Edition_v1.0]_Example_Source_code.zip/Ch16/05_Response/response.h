#ifndef ANSWER2_H
#define ANSWER2_H

#include <QObject>

class Response : public QObject
{
    Q_OBJECT
public:
    explicit Response(QObject *parent = nullptr);

public slots:
    Q_SCRIPTABLE QString answer1(const QString &arg)
    {
        return QString("%1 -> Response-1").arg(arg);
    }

    Q_SCRIPTABLE QString answer2(const QString &arg)
    {
        return QString("%1 -> Response-2").arg(arg);
    }
};

#endif // ANSWER2_H
